import socket, threading, time,random
alph = open('alph.txt')
abc = alph.read()
key = 8194

shutdown = False
join = False
global banned
banned = False

print("WELCOME TO PyChat")
print(" _______              ______   __                    __     ")
print("/       \            /      \ /  |                  /  |    ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_   ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |  ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/   ")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/ ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/  ")
print("          /  \__$$ |  ")                                      
print("          $$    $$/  ")                                       
print("           $$$$$$/")                                          
print("By: Tikhon Sherstobitov")
class mesh():
    def gen(level,abcg):
        i=0
        m=""
        while not level == i:
            m = m+abcg[random.randint(1,len(abcg))-1]
            i+=1
        return m
class uuid():
    def search(uid):
        se=False
        sfile = open('uuid.txt')
        for sid in sfile.readlines():
            if sid.split('=')[0] == uid:
                se=True
                return sid
        if se == False:
            return '/unfe404'
        sfile.close()
    def gen(ip):
        guid = mesh.gen(random.randint(5,25),abc)
        if uuid.search(guid) == '/unfe404':
            file = open('uuid.txt')
            dump_data = file.read()
            file.close()
            file = open('uuid.txt','w')
            nuuid=guid+'='+ip
            file.write(dump_data+'\n'+nuuid)
            print(nuuid)
            file.close()
            return uuid
        else:
            print('Oops! Found equal uuid!')
def gen(ip):
        guid = mesh.gen(random.randint(5,25),abc)
        if uuid.search(guid) == '/unfe404':
            file = open('uuid.txt')
            dump_data = file.read()
            file.close()
            file = open('uuid.txt','w')
            nuuid=guid+'='+ip
            file.write(dump_data+'\n'+nuuid)
            print(nuuid)
            file.close()
            return uuid
        else:
            print('Oops! Found equal uuid!')
def receving (name, sock):
        while not shutdown:
                try:
                        while True:
                                data, addr = sock.recvfrom(1024)
                                #print(data.decode("utf-8"))

                                # Begin
                                decrypt = ""; k = False
                                for i in data.decode("utf-8"):
                                        if i == ":":
                                                k = True
                                                decrypt += i
                                        elif k == False or i == " ":
                                                decrypt += i
                                        else:
                                                decrypt += chr(ord(i)^key)
                                fj = data.decode("utf-8")
                                if fj.split(':')[0] == '/banned':
                                     print('You has banned on this server! Reason: '+fj.split(':')[1])
                                     
                                     s.close()
                                     time.sleep(2)
                                     exit()
                                print(data.decode('utf-8'))
                                # End

                                time.sleep(1)
                except:
                        pass
host = socket.gethostbyname(socket.gethostname())
port = 0

getip = ""
getport = ""
'''
ct=input("Custom setings/Standart setings(Only for test!)?:")

if ct == "Custom setings":
        print("test ip = 127.0.1.1")
        getip = input("server IP = ")
        print("test port = 9090")
        getport = input("Server Pprt = ")
if ct == "Standart setings":
        getip = "127.0.1.1"
        getport = 9090
server = (str(getip),int(getport))
'''
count = 1
server_list = open('server.txt')
for server in server_list.readlines():
        print(str(count)+'. Name: '+' Ip:'+server.split('=')[1]+' Port:'+server.split('=')[2])
        count=count+1
ct = input('Serer:')
getip = server.split('=')[1]
getport = server.split('=')[2]
s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
s.setblocking(0)
alias = input("Name: ")
rules=open('rules.txt')
print(rules.read())

server = (str(getip),int(getport))

rT = threading.Thread(target = receving, args = ("RecvThread",s))
rT.start()

while shutdown == False:
        if join == False:
                s.sendto(("["+alias+':'+str(gen(host))+':'+"] => join chat ").encode("utf-8"),server)
                join = True
        else:
                try:
                        message = input()

                        # Begin
                        crypt = ""
                        for i in message:
                                crypt += chr(ord(i)^key)
                        message = crypt
                        
                        # End

                        if message != "":
                                s.sendto(("["+alias + "] :: "+message).encode("utf-8"),server)
                        
                        time.sleep(1.2)
                except:
                        s.sendto(("["+alias + "] <= left chat ").encode("utf-8"),server)
                        shutdown = True

rT.join()
s.close()
