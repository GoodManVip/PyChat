import socket, threading, time,random
alph = 'f'
abc = alph
key = 8194

shutdown = False
join = False
global banned
banned = False

print("WELCOME TO PyChat")
print(" _______              ______   __                    __     ")
print("/       \            /      \ /  |                  /  |    ")
print("$$$$$$$  | __    __ /$$$$$$  |$$ |____    ______   _$$ |_   ")
print("$$ |__$$ |/  |  /  |$$ |  $$/ $$      \  /      \ / $$   |  ")
print("$$    $$/ $$ |  $$ |$$ |      $$$$$$$  | $$$$$$  |$$$$$$/   ")
print("$$$$$$$/  $$ |  $$ |$$ |   __ $$ |  $$ | /    $$ |  $$ | __ ")
print("$$ |      $$ \__$$ |$$ \__/  |$$ |  $$ |/$$$$$$$ |  $$ |/  |")
print("$$ |      $$    $$ |$$    $$/ $$ |  $$ |$$    $$ |  $$  $$/ ")
print("$$/        $$$$$$$ | $$$$$$/  $$/   $$/  $$$$$$$/    $$$$/  ")
print("          /  \__$$ |  ")                                      
print("          $$    $$/  ")                                       
print("           $$$$$$/")                                          
print("By: Tikhon Sherstobitov")
class mesh():
    def gen(level,abcg):
        i=0
        m=""
        while not level == i:
            m = m+abcg[random.randint(1,len(abcg))-1]
            i+=1
        return m

def receving (name, sock):
        while not shutdown:
                try:
                        while True:
                                data, addr = sock.recvfrom(1024)
                                #print(data.decode("utf-8"))

                                # Begin
                                decrypt = ""; k = False
                                for i in data.decode("utf-8"):
                                        if i == ":":
                                                k = True
                                                decrypt += i
                                        elif k == False or i == " ":
                                                decrypt += i
                                        else:
                                                decrypt += chr(ord(i)^key)
                                fj = data.decode("utf-8")
                                if fj.split(':')[0] == '/banned':
                                     print('You has banned on this server! Reason: '+fj.split(':')[1])
                                     
                                     s.close()
                                     time.sleep(2)
                                     exit()
                                print(data.decode('utf-8'))
                                # End

                                time.sleep(1)
                except:
                        pass
host = socket.gethostbyname(socket.gethostname())
port = 0

getip = ""
getport = ""

count = 1
server_list = open('server.txt')
for server in server_list.readlines():
        print(str(count)+'. Name: '+' Ip:'+server.split('=')[1]+' Port:'+server.split('=')[2])
        count=count+1
ct = input('Serer:')
getip = server.split('=')[1]
getport = server.split('=')[2]
s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
s.setblocking(0)
alias = 'SERVER'
rules=open('rules.txt')
print(rules.read())

server = (str(getip),int(getport))

rT = threading.Thread(target = receving, args = ("RecvThread",s))
rT.start()

def rand(a,b):
    return random.randint(a,b)

def chatgame():
    message='Send answer: '+str(rand(-100,100))+'+'+str(rand(-100,100))
    return message

def ralarm():
    alarms=['TEST ALARM']
    return alarms[rand(0,len(alarms)-1)]

def genmenu(punkt):
    print('--------------------')
    for i in punkt:
        print('|  ',i,'  |')
    print('--------------------')

def panel():
    print('Welcome to Server manger! v 1.0')
    punkt=['1. Send message by name server','2. Start chat-game','3. Send random alarm']
    genmenu(punkt)
    a=input('>')
    if a=='1':
        msg=input('Message to send:')
        return msg
    if a=='2':
        chatgame()
    if a=='3':
        ralarm()

while shutdown == False:
        if join == False:
                s.sendto(("["+alias+':SERMAN67k90:'+"] => join chat").encode("utf-8"),server)
                join = True
        else:
                #try:
                        
                        message = panel()

                        # Begin
                        crypt = ""
                        for i in message:
                                crypt += chr(ord(i)^key)
                        message = crypt
                        
                        # End

                        if message != "":
                                s.sendto(("["+alias + "] :: "+message).encode("utf-8"),server)
                        
                        time.sleep(1.2)
                #except:
                        #s.sendto(("["+alias + "] <= left chat ").encode("utf-8"),server)
                        #shutdown = True

rT.join()
s.close()
