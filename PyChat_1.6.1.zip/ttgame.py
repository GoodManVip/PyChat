#turtle game
import time,random
days=0
def rand(a,b):
    return random.randint(a,b)
def sleep(a):
    time.sleep(a)
def attack(days):
    chance=rand(-100,100)
    print('Turtle has attacked! Chance to win:'+str(chance))
    if chance==-100:
        print('Turtle died days lived:'+str(days))
        return 'over'
    if chance==100:
        print('Turtle win the battle!')
        return 'win'
    if chance<40:
        a=rand(-100,100)
        if a>0:
            print('Turtle win the battle!')
            return 'win'
        if a<0:
            print('Turtle died days lived:'+str(days))
            return 'over'
    if chance>40:
        a=rand(-100,100)
        if a>0:
            print('Turtle win the battle!')
            return 'win'
        if a<0:
            print('Turtle died days lived:'+str(days))
            return 'over'
while True:
    a=rand(0,1)
    if a==0:
        print('Turtle is sleep 1 second')
        a=rand(0,1)
        if a==0:
            chance=rand(-100,100)
            print('Turtle has attacked! Chance to win:'+str(chance))
            attack(days)
        if a==1:
            print('Turtle go to the travel!')
            a=rand(5,100)
            if a>50:
                print('Turtle want to rest!')
                a=rand(0,1)
                if a==1:
                    chance=rand(-100,100)
                    print('Turtle has attacked! Chance to win:'+str(chance))
                    a = attack(days)
                    if a=='over':
                        break
    days+=1
        
        
